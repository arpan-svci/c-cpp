#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "constants.h"
#include "helper_functions.h"
#include "optab_functions.h"

int loctable[200][2];
int symcount = 0;
int LOCCTR = 0x100;

struct symtab_row
{
	char stat;
	char symbol[WORDLEN];
	int symbol_number;
};
FILE *ofptr;
int symbolc, unresolved_symbols_count;
struct symtab_row SYMTAB[SYMTABSIZE];
int symbol_locs[MAXSYMBOLCOUNT];
int add_label_location(char label[WORDLEN])
{
	int i = hash(label, SYMTABSIZE), p = hash2(label, SYMTABSIZE);
	do
	{
		struct symtab_row *r = SYMTAB + i;
		switch (r->stat)
		{
		case 'e':
			strcpy(r->symbol, label);
			symbol_locs[r->symbol_number = symbolc++] = LOCCTR;
			r->stat = 'd';
			return 0;
			break;
		case 'd':
			return 1;
		case 'u':
			if (strcmp(label, r->symbol) == 0)
			{
				symbol_locs[r->symbol_number] = LOCCTR;
				r->stat = 'd';
				return 0;
			}
			break;
		}
		i += p;
		i %= SYMTABSIZE;
	} while (1);
	return 0;
}

int add_label(char label[WORDLEN])
{
	int i = hash(label, SYMTABSIZE), p = hash2(label, SYMTABSIZE);
	int done = 0;
	do
	{
		struct symtab_row *r = SYMTAB + i;
		switch (r->stat)
		{
		case 'e':
			strcpy(r->symbol, label);
			symbol_locs[r->symbol_number = symbolc++] = -1;
			unresolved_symbols_count++;
			r->stat = 'u';
			done = 1;
			break;
		case 'u':
		case 'd':
			if (strcmp(label, r->symbol) == 0)
				done = 1;
			break;
		}
		i += p;
		i %= SYMTABSIZE;
	} while (!done);
	return 0;
}

int get_symbol_no(char label[WORDLEN])
{
	int i = hash(label, SYMTABSIZE), p = hash2(label, SYMTABSIZE);
	do
	{
		struct symtab_row *r = SYMTAB + i;
		switch (r->stat)
		{
		case 'e':
			return -1;
		case 'd':
		case 'u':
			if (strcmp(label, r->symbol) == 0)
				return r->symbol_number;
		}
		i += p;
		i %= SYMTABSIZE;
	} while (1);
	return 0;
}

int is_label_def(char token[WORDLEN])
{
	return token[strlen(token) - 1] == ':';
}

/* formats operand to be easily recognizable */
int format_operand(char operand[WORDLEN])
{

	/*
		!i    :  immediate operand   10H -> !16
		@d    : direct address       [100H] -> @256
		#r    : direct address. address in register r  [di] -> #15
		$l    : direct address. address is a symbol. l = symbol number  [SYMBOL] -> $5 
		%r    : r = register code AX ->  %0
		^s    : symbol. s = symbol number. will transform into a 16 bit word  SYMBOL -> ^5
	*/

	char buffer[WORDLEN];
	if ('0' <= operand[0] && operand[0] <= '9')
	{
		// immediate value
		int val;
		if (form_number(operand, &val))
			return 1;
		if (val < -32768 || val >= 32768)
			return 1;
		sprintf(operand, "!%d", val);
	}
	else if (operand[0] == '\'')
	{
		int c = operand[1];
		if (operand[2] != '\'')
			return 1;
		sprintf(operand, "!%d", c);
	}
	else if (operand[0] == '[')
	{
		strcpy(buffer, operand + 1);
		buffer[strlen(buffer) - 1] = '\0';
		if ('0' <= buffer[0] && buffer[0] <= '9')
		{
			int val;
			if (form_number(buffer, &val))
				return 1;
			if (val < -32768 || val >= 32768)
				return 1;
			sprintf(operand, "@%d", val);
		}
		else if (is_register(buffer))
		{
			int r = get_register_code(buffer);
			sprintf(operand, "#%x", r);
		}
		else if (!is_valid_label(buffer))
			return 1;
		else
		{
			add_label(buffer);
			int l = get_symbol_no(buffer);
			sprintf(operand, "$%d", l);
		}
	}
	else if (is_register(operand))
	{
		sprintf(operand, "%%%d", get_register_code(operand));
	}
	else if (!is_valid_label(operand))
		return 1;
	else
	{
		add_label(operand);
		int s = get_symbol_no(operand);
		sprintf(operand, "^%d", s);
	}
	return 0;
}

void write_to_output(char *outline)
{
	fprintf(ofptr, "%s\n", outline);
}

void init()
{
	ofptr = NULL;
	ofptr = fopen("pass2_inp.txt", "w");
	open_input_file("pass1_inp.txt");
	struct symtab_row *end = SYMTAB + SYMTABSIZE;
	struct symtab_row *ptr = SYMTAB;
	while (ptr != end)
		(ptr++)->stat = 'e';
}

void wrapup()
{
	close_input_file();
	fclose(ofptr);
	ofptr = fopen("symbols.txt", "w");
	for (int i = 0; i < symbolc; i++)
		fprintf(ofptr, "%d\n", symbol_locs[i]);
	fclose(ofptr);
}

int close_files_raise_error()
{
	close_input_file();
	fclose(ofptr);
	return 1;
}

int pass1()
{
	init();
	char OPCODE[WORDLEN], LABEL[WORDLEN], OPERAND1[WORDLEN], OPERAND2[WORDLEN], OUTLINE[LINELEN + 15];
	do
	{
		if (read_line())
			return close_files_raise_error(); // if read line returns error, we break
		if (!has_more_tokens())
			continue;
		get_token();
		if (is_label_def(token)) // all lines may not have label
		{
			strcpy(LABEL, token);
			LABEL[strlen(LABEL) - 1] = '\0';
			if (!is_valid_label(LABEL))
				return close_files_raise_error();
			if (add_label_location(LABEL))
				return close_files_raise_error();
			if (!has_more_tokens())
				continue;
			get_token();
		}

		/*

			Whenever a label or a symbol is encountered, it is assigned a label/symbol number.
			Labels are not written in the output of PASS 1.

			A line in the output of pass 1 will generally follow one of the patterns:
			B \t OPCODE \t OP1 \t OP2 \n (no spaces) or,
			W \t OPCODE \t OP1 \t OP2 \n (no spaces)

			There is one exception only.

			A statement like:
			DB "ABCD$"
			will be converted to
			B	DB	*	*
			ABCD$
			(no quotes in output)

			However a statement like:
			DB 10
			will be converted to
			B	DB	10	*

		 */
		if (strcmp(token, "END") == 0) // if token is end, end of program
			break;
		else if (strcmp(token, "RESW") == 0)
		{ // reserve words. Must be followed by number of tokens
			if (!has_more_tokens())
				return close_files_raise_error();
			get_token();
			int c;
			if (form_number(token, &c))
				return close_files_raise_error(); // could not form number
			if (c >= 0xffff)
				return close_files_raise_error();
			LOCCTR += c << 1; // word is 16 bits. so update locctr by 2c
			sprintf(OUTLINE, "W\tRESW\t%d\t*", c);
		}
		else if (strcmp(token, "RESB") == 0)
		{ // reserve bytes
			if (!has_more_tokens())
				return close_files_raise_error();
			get_token();
			int c;
			if (form_number(token, &c))
				return close_files_raise_error();
			if (c >= 0xffff)
				return close_files_raise_error();
			LOCCTR += c;
			sprintf(OUTLINE, "B\tRESB\t%d\t*", c);
		}
		else if (strcmp(token, "DW") == 0)
		{
			if (!has_more_tokens())
				return close_files_raise_error();
			get_token();
			int w;
			if (form_number(token, &w))
				return close_files_raise_error();
			if (w > 0xffff)
				return close_files_raise_error();
			LOCCTR += 2;
			sprintf(OUTLINE, "W\tDW\t%d\t*", w);
		}
		else if (strcmp(token, "DB") == 0)
		{
			if (!has_more_tokens())
				return close_files_raise_error();
			/*
				two possibilities here of following form:
				DB 10
				DB "ABCD$"
			 */
			if (is_next_token_string())
			{
				parse_string_as_next_token();
				int strl = strlen(str);
				LOCCTR += strl;
				sprintf(OUTLINE, "B\tDB\t*\t*\n%s", str);
			}
			else
			{
				get_token();
				LOCCTR++;
				int b;
				if (form_number(token, &b))
					return close_files_raise_error();
				if (b >= 0xff)
					return close_files_raise_error();
				sprintf(OUTLINE, "B\tDB\t%d\t*", b);
			}
		}
		else if (!is_opcode(token))
			return close_files_raise_error();
		else
		{
			strcpy(OPCODE, token);
			/*
				3 types
				OP A, B
				OP A
				OP
			 */
			int l = 0, argc = 0, word16;
			if (has_more_tokens())
			{
				get_token();
				strcpy(OPERAND1, token);
				if (format_operand(OPERAND1))
					return close_files_raise_error();
				if (has_more_tokens())
				{
					get_token();
					strcpy(OPERAND2, token);
					if (format_operand(OPERAND2))
						return close_files_raise_error();
					if (!verify(OPCODE, OPERAND1, OPERAND2))
						return close_files_raise_error();
					if (has_more_tokens())
						return close_files_raise_error(); // if there are more tokens then invalid
					l = get_instruction_length_and_mem(OPCODE, OPERAND1, OPERAND2, &word16);
					argc = 2;
				}
				else if (!verify(OPCODE, OPERAND1, NULL))
					return close_files_raise_error();
				else
				{
					l = get_instruction_length_and_mem(OPCODE, OPERAND1, NULL, &word16);
					argc = 1;
				}
			}
			else if (!verify(OPCODE, NULL, NULL))
				return close_files_raise_error();
			else
				l = get_instruction_length_and_mem(OPCODE, NULL, NULL, &word16);
			LOCCTR += l;
			if (argc == 2)
				sprintf(OUTLINE, "%c\t%s\t%s\t%s", word16 ? 'W' : 'B', OPCODE, OPERAND1, OPERAND2);
			else if (argc == 1)
				sprintf(OUTLINE, "%c\t%s\t%s\t*", word16 ? 'W' : 'B', OPCODE, OPERAND1);
			else
				sprintf(OUTLINE, "%c\t%s\t*\t*", word16 ? 'W' : 'B', OPCODE);
		}
		write_to_output(OUTLINE);
		if (LOCCTR > 65536)
			return 1 + close_files_raise_error();

	} while (1);
	if (unresolved_symbols_count)
		return 2 + close_files_raise_error();
	wrapup();
	return 0;
}
