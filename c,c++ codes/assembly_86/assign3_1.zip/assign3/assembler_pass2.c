#include<stdio.h>
char* corrospondingbin(char *reg){
    if(reg[1]=='0')
        return "000";
    else if(reg[1]=='1')
        return "001";
    else i(reg[1]==)
}
char* register_mode(char* MOD,char* reg,char* reg){
    char* mydes;
    if(reg[1]=='0')
        mydes="000";
    else if(reg[1]=='1')
        mydes="001";
    else if(reg[2]=='2')
        mydes="010";
    else if()
    char* first=
}
void read(){
    char* first,second,third,fourth;
    char* out[6];
    int location=0;
    if(first=="W"){
        if(strcmp(second,"DB")==0){
            if(third=="*"&&fourth=="*"){
                location++;
                out[0]=first;
            }
            else if(strcmp(fourth,"*")==0&&strcmp(third,"*")!=0){

            }
        }
        else if(strcmp(second,"MOV")==0){
            if(third[0]=='%'&&fourth[0]=='%'){
                out[0]="89";
                out[1]=register_mode(MOD,reg,reg);
            }
            else if(third[0]=='%'&& fourth[0]=='!'){
                out[0]="B8";
            }
            else if(strcmp(third,"%0")==0 && (fourth[0]=='@'||fourth[0]=='#'||fourth[0]=='$')){
                out[0]="A1";
            }
            else if((third[0]=='@'||third[0]=='#'||third[0]=='$')&&fourth[0]=='%'){
                out[0]="89";
            }
            else if((third[0]=='@'||third[0]=='#'||third[0]=='$')&&strcmp(fourth,"%0")==0){
                out[0]="A3";
            }
        }
        else if(strcmp(second,"INC")==0){
            if(third[0]=='%'){
                out[0]="40";
            }
            else if(third[0]=='@'||third[0]=='#'||third[0]=='$'){
                out[0]="FF";
            }
        }
        else if(strcmp(second,"DEC")==0){
            if(third[0]=='%'){
                out[0]="48";
            }
            else if(third[0]=='@'||third[0]=='#'||third[0]=='$'){
                out[0]="FF";
            }
        }
        else if(strcmp(second,"ADD")==0){
            if((third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$')&&fourth[0]=='%'){
                out[0]="01";
            }
            if(third[0]=='%'&&(fourth[0]=='%'||fourth[0]=='@'||fourth[0]=='#'||fourth[0]=='$'){
                out[0]="03";
            }
            else if(third[0]=='%'&& fourth[0]=='!'){
                out[0]="81";
            }
            else if(strcmp(third,"%0")==0 && fourth[0]=='!'){
                out[0]="05";
            }
        }
        else if(strcmp(second,"AND")==0){
            if((third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$')&&fourth[0]=='%'){
                out[0]="21";
            }
            if(third[0]=='%'&&(fourth[0]=='%'||fourth[0]=='@'||fourth[0]=='#'||fourth[0]=='$'){
                out[0]="23";
            }
            else if(third[0]=='%'&& fourth[0]=='!'){
                out[0]="A1";
            }
            else if(strcmp(third,"%0")==0 && fourth[0]=='!'){
                out[0]="25";
            }
        }
        else if(strcmp(second,"OR")==0){
            if((third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$')&&fourth[0]=='%'){
                out[0]="09";
            }
            if(third[0]=='%'&&(fourth[0]=='%'||fourth[0]=='@'||fourth[0]=='#'||fourth[0]=='$'){
                out[0]="0B";
            }
            else if(third[0]=='%'&& fourth[0]=='!'){
                out[0]="89";
            }
            else if(strcmp(third,"%0")==0 && fourth[0]=='!'){
                out[0]="0D";
            }
        }
        else if(strcmp(second,"XOR")==0){

        }
        else if(strcmp(second,"SUB")==0){

        }
        else if(strcmp(second,"JMP")==0){
            out[0]="EA";
        }
        else if(strcmp(second,"JL")==0){
            out[0]="7C";
        }
        else if(strcmp(second,"JG")==0){
            out[0]="7F";
        }
        else if(strcmp(second,"JZ")==0){
            out[0]="74";
        }
        else if(strcmp(second,"cmp")==0){
        }
        else if(strcmp(second,"MOV")==0){
        }
        else if(strcmp(second,"INT")==0){

        }
        else if(strcmp(second,"RESW")==0){

        }
        else if(strcmp(second,"CLC")==0){

        }
    }
    if(first=="B"){
        if(strcmp(second,"MOV")==0){
            if(third[0]=='%'&&fourth[0]=='%'){
                out[0]="88";
            }
            else if(third[0]=='%'&& fourth[0]=='!'){
                out[0]="B0";
            }
            else if(strcmp(third,"%0")==0 && fourth[0]=='@'||fourth[0]=='#'||fourth[0]=='$'){
                out[0]="A0";
            }
            else if(third[0]=='@'||third[0]=='#'||third[0]=='$'&&fourth[0]=='%'){
                out[0]="88";
            }
            else if(third[0]=='@'||third[0]=='#'||third[0]=='$'&&strcmp(fourth,"%0")==0){
                out[0]="A2";
            }
        }
        else if(strcmp(second,"INC")==0){
            if(third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$'){
                out[0]="FE";
            }
        }
        else if(strcmp(second,"DEC")==0){
            if(third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$'){
                out[0]="FE";
            }
        }
        else if(strcmp(second,"ADD")==0){
            if((third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$')&&fourth[0]=='%'){
                out[0]="00";
            }
            if(third[0]=='%'&&(fourth[0]=='%'||fourth[0]=='@'||fourth[0]=='#'||fourth[0]=='$'){
                out[0]="02";
            }
            else if((third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$')&& fourth[0]=='!'){
                out[0]="80";
            }
            else if(strcmp(third,"%0")==0 && fourth[0]=='!'){
                out[0]="05";
            }
        }
        else if(strcmp(second,"AND")==0){
             if((third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$')&&fourth[0]=='%'){
                out[0]="20";
            }
            if(third[0]=='%'&&(fourth[0]=='%'||fourth[0]=='@'||fourth[0]=='#'||fourth[0]=='$'){
                out[0]="24";
            }
            else if((third[0]=='%'||third[0]=='@'||third[0]=='#'||third[0]=='$')&& fourth[0]=='!'){
                out[0]="A0";
            }
            else if(strcmp(third,"%0")==0 && fourth[0]=='!'){
                out[0]="25";
            }
        }
        else if(strcmp(second,"OR")==0){

        }
        else if(strcmp(second,"XOR")==0){

        }
        else if(strcmp(second,"SUB")==0){

        }
        else if(strcmp(second,"JMP")==0){
            out[0]="EA";
        }
        else if(strcmp(second,"JL")==0){
            out[0]="7C";
        }
        else if(strcmp(second,"JG")==0){
            out[0]="7F";
        }
        else if(strcmp(second,"JZ")==0){
            out[0]="74";
        }
        else if(strcmp(second,"cmp")==0){

        }
        else if(strcmp(second,"INT")==0){

        }
        else if(strcmp(second,"RESW")==0){

        }
        else if(strcmp(second,"CLC")==0){

        }
    }
}