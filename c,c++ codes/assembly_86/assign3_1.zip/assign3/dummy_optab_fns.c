#include <stdlib.h>
#include <stdio.h>
#include "optab_functions.h"

int is_opcode(char token[WORDLEN]) { return 1; }

int verify(char def,char second[WORDLEN], char OP1[WORDLEN], char OP2[WORDLEN]) {
	if(def=='W'){
		if(second=="DB"){

        }
        else if(strcmp(second,"MOV")==0){

        }
        else if(second=="INC"){

        }
        else if(second=="DEC"){

        }
        else if(second=="ADD"){

        }
        else if(second=="AND"){

        }
        else if(second=="OR"){

        }
        else if(second=="XOR"){

        }
        else if(second=="SUB"){

        }
        else if(second=="JMP"){

        }
        else if(second=="JL"){

        }
        else if(second=="JG"){

        }
        else if(second=="JZ"){

        }
        else if(second=="cmp"){

        }
        else if(second=="MOV"){

        }
        else if(second=="INT"){

        }
        else if(second=="RESW"){

        }
        else if(second=="CLC"){

        }
	}
	if(def=='B'){

	}
	 return 1;
}

int get_instruction_length_and_mem(char OPCODE[WORDLEN], char OP1[WORDLEN], char OP2[WORDLEN], int *word)
{
	*word = (rand() & 1);
	return 6;
}