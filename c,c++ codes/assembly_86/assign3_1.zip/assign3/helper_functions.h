#include "constants.h"

extern char token[WORDLEN];
extern char line[LINELEN];
extern char str[LINELEN];

extern int open_input_file(const char* filename);
extern void close_input_file();

/* fills buffer 'line' with a next line */
extern int read_line();

/* from the buffer 'line', gets a token and fills */
extern void get_token();

/* returns 0 if no more tokens */
extern int has_more_tokens();

/* returns a value in [0,n-1] */
extern int hash(char *word,int n);

/* returns a value in [1,n-1] */
extern int hash2(char*,int n);

/* tells if next token is a string or not */
extern int is_next_token_string();

/* to parse a string. To take a token of size > 20 */
extern int parse_string_as_next_token();

/* returns true if it is a register name */
extern int is_register(char operand[WORDLEN]);

/* */
extern int form_number(char operand[WORDLEN],int* ans);

/* tells if a label is valid or not */
extern int is_valid_label(char label[WORDLEN]);

/* gives register code from register name */
extern int get_register_code(char reg[WORDLEN]);