#include "helper_functions.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

FILE *inputfptr;

char line[LINELEN];
char str[LINELEN];
char token[WORDLEN];

char *rptr;

int open_input_file(const char *filename)
{
	inputfptr = fopen(filename, "r");
	return inputfptr == NULL;
}

void close_input_file()
{
	if (inputfptr != NULL)
		fclose(inputfptr);
	inputfptr = NULL;
}

int read_line()
{
	if (EOF == fscanf(inputfptr, "%[^\n]%*c", line))
		return 1;
	rptr = line;
	while (*rptr)
	{
		if ('A' <= *rptr && *rptr <= 'Z')
			break;
		if ('0' <= *rptr && *rptr <= '9')
			break;
		if ('_' == *rptr || *rptr == ':' || *rptr == '"')
			break;
		rptr++;
	}
	return 0;
}

void get_token()
{
	char *ptr = token;
	if (*rptr == '"')
		*rptr = '\0';
	while ((*rptr) && (('A' <= *rptr && *rptr <= 'Z') || ('0' <= *rptr && *rptr <= '9') || '_' == *rptr || *rptr == ':'))
		*(ptr++) = *(rptr++);
	*ptr = '\0';
	while (*rptr)
	{
		if ('A' <= *rptr && *rptr <= 'Z')
			break;
		if ('0' <= *rptr && *rptr <= '9')
			break;
		if ('_' == *rptr || *rptr == ':' || *rptr == '"')
			break;
		rptr++;
	}
}

int has_more_tokens()
{
	return *rptr;
}

int hash(char *word, int n)
{
	int h = 5381, c;
	while (c = *(word++))
		h = h * 33 ^ c;
	return h % n;
}

int hash2(char *word, int n)
{
	int h = 0;
	while (*word)
		h += *(word++);
	return 1 + h % (n - 1);
}

int is_next_token_string() { return *rptr == '"'; }

int parse_string_as_next_token()
{
	char *ptr = str;
	if (*rptr == '"')
	{
		rptr++;
		while (*rptr != '"')
			*(ptr++) = *(rptr++);
		return 0;
	}
	return 1;
}

int is_register(char operand[WORDLEN])
{
	if (operand[2] != '\0')
		return 0;
	switch (operand[0])
	{
	case 'A':
		switch (operand[1])
		{
		case 'L':
		case 'H':
		case 'X':
			return 1;
		}
		break;
	case 'B':
		switch (operand[1])
		{
		case 'L':
		case 'H':
		case 'P':
		case 'X':
			return 1;
		}
		break;
	case 'C':
		switch (operand[1])
		{
		case 'L':
		case 'H':
		case 'X':
			return 1;
		}
		break;
	case 'D':
		switch (operand[1])
		{
		case 'L':
		case 'H':
		case 'I':
		case 'X':
			return 1;
		}
		break;
	case 'S':
		switch (operand[1])
		{
		case 'I':
		case 'P':
			return 1;
		}
		break;
	}
	return 0;
}

int form_number(char operand[WORDLEN], int *ans)
{
	int l = strlen(operand);
	char *ch = operand, *end = ch + l;
	int num = 0;
	if (operand[l - 1] == 'H')
	{
		end--;
		while (ch != end)
		{
			num <<= 4;
			if ('0' <= *ch && *ch <= '9')
				num += *ch - '0';
			else if ('A' <= *ch && *ch <= 'F')
				num += *ch - 'A' + 10;
			else
				return 1;
			ch++;
		}
	}
	else
	{
		while (ch != end)
		{
			num *= 10;
			if ('0' <= *ch && *ch <= '9')
				num += *ch - '0';
			else
				return 1;
			ch++;
		}
	}
	*ans = num;
	return 0;
}

int is_valid_label(char label[WORDLEN])
{
	if (is_register(label))
		return 0;
	if (label[0] > 'Z' || label[0] < 'A')
		return 0;
	return 1;
}

int get_register_code(char reg[WORDLEN])
{
	if (reg[2] != '\0')
		return -1;
	switch (reg[0])
	{
	case 'A':
		switch (reg[1])
		{
		case 'L':
			return 0b0000;
		case 'H':
			return 0b0100;
		case 'X':
			return 0b1000;
		}
		break;
	case 'B':
		switch (reg[1])
		{
		case 'L':
			return 0b0011;
		case 'H':
			return 0b0111;
		case 'P':
			return 0b1101;
		case 'X':
			return 0b0011;
		}
		break;
	case 'C':
		switch (reg[1])
		{
		case 'L':
			return 0b0001;
		case 'H':
			return 0b0101;
		case 'X':
			return 0b1001;
		}
		break;
	case 'D':
		switch (reg[1])
		{
		case 'L':
			return 0b0010;
		case 'H':
			return 0b0110;
		case 'I':
			return 0b1111;
		case 'X':
			return 0b1010;
		}
		break;
	case 'S':
		switch (reg[1])
		{
		case 'I':
			return 0b1110;
		case 'P':
			return 0b1100;
		}
		break;
	}
	return -1;
}