#include <stdlib.h>
#include <stdio.h>
#include <helper_functions.h>

/* uses read_line and get_token to parse*/
void process_macros(){

}