extern int pass1();
int main()
{
	return pass1();
}