#include "constants.h"

extern int is_opcode(char token[WORDLEN]);

extern int verify(char OPCODE[WORDLEN], char OP1[WORDLEN], char OP2[WORDLEN]);

extern int get_instruction_length_and_mem(char OPCODE[WORDLEN], char OP1[WORDLEN], char OP2[WORDLEN], int* word);